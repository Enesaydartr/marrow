using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("SLZ.Marrow.Editor")]