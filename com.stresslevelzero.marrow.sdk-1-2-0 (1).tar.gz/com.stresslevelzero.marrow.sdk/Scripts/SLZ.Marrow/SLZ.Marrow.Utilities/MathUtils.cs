using UnityEngine;

namespace SLZ.Marrow.Utilities
{
    public static class MathUtils
    {
        public static readonly float Epsilon = Mathf.Epsilon;
    }
}