 

namespace SLZ.Marrow.Zones
{
    public interface IZoneEntityListenable
    {
    }

    public interface IZoneBodyListenable
    {
    }

    public interface IZoneTrackerListenable
    {
    }
}