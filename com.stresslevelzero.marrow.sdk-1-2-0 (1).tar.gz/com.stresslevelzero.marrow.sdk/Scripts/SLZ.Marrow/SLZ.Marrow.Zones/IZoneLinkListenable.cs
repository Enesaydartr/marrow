 

namespace SLZ.Marrow.Zones
{
    public interface IZoneLinkListenable
    {
    }

    public interface IZoneLinkPrimaryListenable
    {
    }

    public interface IZoneLinkSecondaryListenable
    {
    }
}