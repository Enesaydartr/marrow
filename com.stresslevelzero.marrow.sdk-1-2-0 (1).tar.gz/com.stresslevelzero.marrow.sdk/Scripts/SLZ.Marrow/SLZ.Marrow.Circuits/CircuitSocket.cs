using UnityEngine;

namespace SLZ.Marrow.Circuits
{
    public class CircuitSocket : Circuit
    {
    }
}