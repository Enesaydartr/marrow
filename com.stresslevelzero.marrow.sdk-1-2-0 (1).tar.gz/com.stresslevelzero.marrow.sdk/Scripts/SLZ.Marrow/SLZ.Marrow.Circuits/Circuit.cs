 
using UnityEngine;

namespace SLZ.Marrow.Circuits
{
    public class Circuit : MonoBehaviour
    {
#if UNITY_EDITOR
#endif
    }
}