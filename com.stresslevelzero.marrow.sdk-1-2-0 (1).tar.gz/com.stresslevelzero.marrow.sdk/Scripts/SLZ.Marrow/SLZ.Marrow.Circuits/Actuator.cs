 
using UnityEngine;

namespace SLZ.Marrow.Circuits
{
    public class Actuator : MonoBehaviour
    {
#if UNITY_EDITOR
#endif
    }
}