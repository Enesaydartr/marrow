 
 
using UnityEngine;

namespace SLZ.Marrow.Warehouse
{
    public class BoneTag : DataCard
    {
        public override bool IsBundledDataCard()
        {
            return false;
        }
    }
}