 
 
using UnityEngine;

namespace SLZ.Marrow.Warehouse
{
    public class VFXCrate : SpawnableCrate
    {
    }
}