using UnityEngine.EventSystems;

namespace SLZ.Marrow.Combat
{
    public interface IAttackReceiver : IEventSystemHandler
    {
    }
}