# UnityMeshSimplifier contributors

A special thanks goes out to all contributors of this project.

The names are sorted alphabetically.

* **[amirebrahimi](https://github.com/amirebrahimi)**
* **[bawar9](https://github.com/bawar9)**
* **[is3D-1](https://github.com/is3D-1)**
* **[sbeca](https://github.com/sbeca)**
* **[soraryu](https://github.com/soraryu)**

See the full list of contributors [here](https://github.com/Whinarn/UnityMeshSimplifier/graphs/contributors).
